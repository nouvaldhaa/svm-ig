import pathlib
import pandas as pd
import string
import re
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords


class Preprocessing:
    
    lemmatizer = WordNetLemmatizer()
    term_dict = {}

    
    def input_data(self, path):
        
        file = pathlib.Path(path)
        if file.exists():
            self.dataset = pd.read_excel(path)
        else:
            print('Path error : tidak ada data pada path ->',path)

    def remove_special(self, text):
    # remove tab, new line, ans back slice
        text = text.replace('\\t'," ").replace('\\n'," ").replace('\\u'," ").replace('\\',"")
    # remove non ASCII (emoticon, chinese word, .etc)
        text = text.encode('ascii', 'replace').decode('ascii')
    # remove mention, link, hashtag
        text = ' '.join(re.sub("([@#][A-Za-z0-9]+)|(\w+:\/\/\S+)"," ", text).split())
    # remove incomplete URL
        return text.replace("http://", " ").replace("https://", " ")
    
    def remove_username(self, text):
    # menghilangkan tanda [USERNAME]
        processed_text = text.replace('username', '')
        return processed_text

    def remove_number(self, text):
        return  re.sub(r"\d+", "", text)
 
    def remove_punctuation(self, text):
        return text.translate(str.maketrans("","",string.punctuation))

    def remove_whitespace_LT(self, text):
        return text.strip()

    def remove_whitespace_multiple(self, text):
        return re.sub('\s+',' ',text)

    def remove_singl_char(self, text):
        return re.sub(r"\b[a-zA-Z]\b", "", text)    

    def word_tokenize_wrapper(self, text):
        return word_tokenize(text)

  #----------------End Tokenizing---------------------      
    
    def stopwords_removal(self, words):
        list_stopwords = stopwords.words('english')
        list_stopwords = set(list_stopwords)
        return [self.lemmatizer.lemmatize(word) for word in words if word not in list_stopwords]
  

    # def stemmed_wrapper(self, term):
    #     return self.stemmer.stem(term)

    # def get_stemmed_term(self, document):
    #     term_list = self.term_dict
    #     return [term_list[term] for term in document]


    def praprosses_data(self):
        if self.dataset is not None:
            print('Running Preprocessing...')
            data_pc = self.dataset
            tokenizing_remove = self.remove_special
            remove_username = self.remove_username
            remove_number = self.remove_number
            remove_punctuation = self.remove_punctuation
            remove_whitespace_LT = self.remove_whitespace_LT
            remove_whitespace_multiple = self.remove_whitespace_multiple
            remove_singl_char = self.remove_singl_char
            tokenizing = self.word_tokenize_wrapper
            data_stopwords = self.stopwords_removal  


            print('Self Dataset Selesai') #noise removal

            data_pc['komentar'] = data_pc['komentar'].str.lower()
            print('Case Folding Selesai')

            data_pc['komentar'] = data_pc['komentar'].apply(lambda text: re.sub('@[^\s]+', '', text))
            
            data_pc['komentar'] = data_pc['komentar'].apply(lambda text: re.sub(r'#([^\s]+)', '', text))
            

            data_pc['komentar'] = data_pc['komentar'].apply(lambda text: re.sub(r"[^a-zA-Z0-9]+", ' ', text))
            print('Noise Removal 1 Selesai')

            data_pc['komentar'] = data_pc['komentar'].apply(lambda text: re.sub(r'(.)\1{2,}', r'\1', text))    
            print('Noise Removal 2 Selesai')  

            data_pc['komentar'] = data_pc['komentar'].apply(remove_username)
            

            # ------------------Proses Tokenizing ------------------

            data_pc['komentar'] = data_pc['komentar'].apply(tokenizing_remove)
            print('Remove Special Character Selesai')

            data_pc['komentar'] = data_pc['komentar'].apply(remove_number)
            print('Remove Number Selesai')
            
            data_pc['komentar'] = data_pc['komentar'].apply(remove_punctuation)
            print('Remove Punctuation Selesai')

            data_pc['komentar'] = data_pc['komentar'].apply(remove_whitespace_LT)
            data_pc['komentar'] = data_pc['komentar'].apply(remove_whitespace_multiple)
            print('Remove Whitespace Selesai')

            data_pc['komentar'] = data_pc['komentar'].apply(remove_singl_char)

            data_pc['komentar'] = data_pc['komentar'].apply(tokenizing)
            print('Tokenizing Selesai')

            #------------------ End Proses Tokenizing -------------------


            data_pc['komentar'] = data_pc['komentar'].apply(data_stopwords)
            print('Stopword Removal Selesai')

            data_pc['komentar'] = data_pc['komentar'].apply(' ' .join)

            data_pc.to_excel("Asset/HasilPreprocessing.xlsx")
            print('Data Berhasil Disimpan !!')  

        return data_pc