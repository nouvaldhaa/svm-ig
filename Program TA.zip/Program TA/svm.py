import pathlib
import pandas as pd
from sklearn import svm
import time
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import confusion_matrix
import string
import re
from nltk.tokenize import word_tokenize
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
from nltk.tokenize.toktok import ToktokTokenizer
import numpy as np
from sklearn.svm import SVC
from sklearn.multiclass import OneVsOneClassifier, OneVsRestClassifier
from sklearn.model_selection import KFold
import time
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
import swifter
import ast
import contractions
from Preprocessing import Preprocessing
    

class SVM:
           
    def tanpa_feature_selection(self):
        dataframe = pd.read_excel('Asset/HasilPreprocessing.xlsx')
        return dataframe
            
    def get_dataset(self):
        dataframe = pd.read_excel('Asset/HasilPreprocessing.xlsx')
        return dataframe
    
    def get_total_feature(self,dataset):
        vectorizer = TfidfVectorizer()
        X = vectorizer.fit_transform(dataset['komentar'].astype('U').values)
        return X.shape[1]

    def join_text_list(self,texts):
        texts = ast.literal_eval(str(texts))
        return ' '.join([text for text in texts])
    
    def classify(self,dataset,c_clf):

        print(dataset)
        print(c_clf)

        dataset = dataset.sample(frac=1).reset_index(drop=True)
        vectorizer = TfidfVectorizer(use_idf=True)

        X = vectorizer.fit_transform(dataset['komentar'])
        Y = dataset['label']

        SVM = OneVsOneClassifier(svm.SVC(C=c_clf,kernel='linear'))
        scores = []
        scores.append(['Uji ke','TP','FP','TN','FN','Akurasi','Precision','Recall','F-Measure','Waktu Komputasi'])
        cv = KFold(n_splits=10)
        index_hasil = 1

        for train_index, test_index in cv.split(X): #hyperplane
            X_train, X_test, Y_train, Y_test = X[train_index], X[test_index], Y[train_index], Y[test_index]
            start_time = time.time()
            SVM.fit(X_train,Y_train) #training
            Y_pred = SVM.predict(X_test) #test
            Cm = confusion_matrix(Y_test, Y_pred)
            print(Cm)
            Tp = (Cm[1][1])
            Fn = (Cm[1][0])
            Fp = (Cm[0][1])   
            Tn = (Cm[0][0])
            acc = round(accuracy_score(Y_test,Y_pred),2)
            prec = round(precision_score(Y_test,Y_pred, average = 'macro'),2)
            rec = round(recall_score(Y_test,Y_pred, average = 'macro'),2)
            f1 = round(f1_score(Y_test,Y_pred, average = 'macro'),2)    
            #f1 = f1_score(Y_test,Y_pred)
            execution_time = round((time.time() - start_time),2)
            scores.append([index_hasil,Tp,Fp,Tn,Fn,acc,prec,rec,f1,execution_time])
            index_hasil +=1
            
        temp = ['Rata-rata', ' ',' ',' ',' ',0,0,0,0,0]
        for i in range(1,11):
            for j in range(5,10):
                temp[j] += scores[i][j]
        
        for i in range(5,10):
            temp[i] = round((temp[i]/10),2)
                
        scores.append(temp)
        print(scores)

        self.model = SVM
        return scores
    
    def predicttanpaseleksifitur(self,text):
        proses = Preprocessing()
        datas = pd.Series(data = [text])
        tokenizing_remove = proses.remove_tweet_special
        remove_username = proses.remove_username
        remove_number = proses.remove_number
        remove_punctuation = proses.remove_punctuation
        remove_whitespace_LT = proses.remove_whitespace_LT
        remove_whitespace_multiple = proses.remove_whitespace_multiple
        remove_singl_char = proses.remove_singl_char
        tokenizing = proses.word_tokenize_wrapper
        data_stopwords = proses.stopwords_removal  


        datas = datas.str.lower()
        datas = datas.apply(lambda text: re.sub('@[^\s]+', '', text))       
        datas = datas.apply(lambda text: re.sub(r'#([^\s]+)', '', text))
        datas = datas.apply(lambda text: re.sub(r"[^a-zA-Z0-9]+", ' ', text))
        datas = datas.apply(lambda text: re.sub(r'(.)\1{2,}', r'\1', text))    
    
        datas = datas.apply(remove_username)
            

            # ------------------Proses Tokenizing ------------------

        datas = datas.apply(tokenizing_remove)
        datas = datas.apply(remove_number)
        datas = datas.apply(remove_punctuation)
        datas = datas.apply(remove_whitespace_LT)
        datas = datas.apply(remove_whitespace_multiple)
        datas = datas.apply(remove_singl_char)
        datas = datas.apply(tokenizing)
        
        #------------------ End Proses Tokenizing -------------------
        datas = datas.apply(data_stopwords)
        datas = datas.apply(' ' .join)
        
        
        vectorizer = TfidfVectorizer(use_idf=True)

        dataset = pd.read_excel('Asset/HasilPreprocessing.xlsx')
        
        TF_IDF = vectorizer.fit(dataset['komentar'].astype('U').values)
        datas = TF_IDF.transform(datas.astype('U').values)
        
        prediction = self.model.predict(datas)
        print(prediction)
                 
        if prediction == 'positif':
            return "Komentar Positif" 
        else :
            return "Komentar Negatif"
        
    
   
             
    
        
        
       

    